import define1 from "./7764a40fe6b83ca1@437.js";
import define2 from "./e93997d5089d7165@2303.js";
import define3 from "./1371b3b2446a73b4@335.js";
import define4 from "./d9e5cc6facdf568b@555.js";
import define5 from "./e76d2c695f356743@796.js";
import define6 from "./600f1f80e771a771@509.js";
import define7 from "./f75b3d782a2196ff@696.js";
import define8 from "./66e14fffe29297e2@222.js";

function _1(md){return(
md`# UMAP playground

👩🏻‍💻 [Better layout version](https://johnguerra.co/viz/umapPlayground/)

A notebook to play with the [UMAP-JS](https://github.com/PAIR-code/umap-js) the dimensionality reduction algorithm and visualization with your own data. This can be useful to find items with similar characteristics comparing across multiple dimensions. All of this will run live on your browser, so I won't recommend it with datasets with more than 1000 records.

From the UMAP library description: 

> Uniform Manifold Approximation and Projection (UMAP) is a dimension reduction technique that can be used for visualisation similarly to t-SNE, but also for general non-linear dimension reduction.

Uses the [USDA's nutrients dataset](https://www.ars.usda.gov/northeast-area/beltsville-md-bhnrc/beltsville-human-nutrition-research-center/methods-and-application-of-food-composition-laboratory/mafcl-site-pages/sr11-sr28/) by default. UMAP code based on [@fil's UMAP-worker](https://observablehq.com/@fil/umap-js-worker)

**Load your data**
`
)}

async function _data(dataInput,FileAttachment,d3,fileType){return(
dataInput({
  initialValue: await FileAttachment("nutrients.csv").text().then(res => d3.csvParse(res, d3.autoType)),
  format: fileType // Optional, one of MongoExport, JSON, CSV, CSVNoAutoType
})
)}

function _fileType(Inputs){return(
Inputs.select(["CSV", "JSON", "CSVNoAutoType", "MongoExport", "auto"], {
  label: "File Type"
})
)}

async function _filteredData(conditionalShow,navio,data,navioOptions,htl){return(
conditionalShow(await navio(data, navioOptions), {
  label: htl.html`<h3 style="display:inline">Filter Data?</h3>`,
  checked: this ? this.checked : true, // keep previous value
 })
)}

function _status(html,umapStatus){return(
html`
    <div>Status: ${umapStatus.status} 
      ${
        umapStatus.status !== "Initializing"
          ? html`Epoch: ${umapStatus.currentEpoch} of ${umapStatus.targetEpoch}`
          : ""
      }</div>
  `
)}

async function _scatterplot(vl,numericColumns,colorCol,filteredDataWithCoords,sizeCol,width,vegaSelected)
{
  const brush = vl.selectInterval("brush").encodings(["x", "y"]);

  const colorField =
    numericColumns.indexOf(colorCol) === -1
      ? vl.color().fieldN(colorCol).scale({
          scheme: "turbo"
        })
      : vl.color().fieldQ(colorCol);

  const chart = await vl
    .markCircle({ tooltip: { data: true } })
    .select(brush)
    .data(filteredDataWithCoords)
    .encode(
      vl.x().fieldQ("x").axis(false),
      vl.y().fieldQ("y").axis(false),
      vl.color().if(brush, colorField).value("#777"),
      vl
        .size()
        .field(sizeCol)
        .scale({ range: [10, 300] })
    )
    .height((width * 2) / 3)
    .width((width * 2) / 3)
    .config({
      scale: { grid: null }
    });

  return vegaSelected(chart.toObject());
}


function _7(md){return(
md`## Choose which attributes to feed to UMAP`
)}

function _selectedColumns(searchCheckbox,columns,numericColumns){return(
searchCheckbox(columns, {
  label: "Select Attributes",
  value: this?.value || numericColumns.filter(d => d !== "id")
})
)}

function _9(md){return(
md`## UMAP Parameters`
)}

function _minDist(slider){return(
slider({
  title:"minDist",
  value: 0.1,
  description: "The effective minimum distance between embedded points, used with spread to control the clumped/dispersed nature of the embedding (defaults to 0.1)"
})
)}

function _spread(slider){return(
slider({
  title:"spread",
  value: 1,
  min:0,
  max:3, 
  step: 0.01,
  description: "The effective scale of embedded points, used with minDist to control the clumped/dispersed nature of the embedding (defaults to 1)"
})
)}

function _nNeighbors(slider){return(
slider({
  title:"nNeighbors",
  value: 15,
  min: 1,
  max: 50,
  step: 1,
  description: "The number of nearest neighbors to construct the fuzzy manifold (defaults to 15)"
})
)}

function _nComponents(slider){return(
slider({
  title:"nComponents",
  value: 2,
  min:1,
  max:50, 
  step: 1,
  description: "The number of components (dimensions) to project the data to (defaults to 2)"
})
)}

function _seed(number){return(
number({
  description: "random seed",
  value: 46
})
)}

function _15(md){return(
md`## Visualization parameters`
)}

function _show_dynamic(checkbox){return(
checkbox({options: ["Show dynamic"], value: "Show dynamic"})
)}

function _sizeCol(select,selectedColumns){return(
select({
  title: "Attribute for Size",
  options: selectedColumns
})
)}

function _colorCol(select,columns,numericColumns){return(
select({
  title: "Attribute for Color",
  options: columns,
  value: columns.indexOf("group")!==-1 ? "group": numericColumns[0]
})
)}

function _19(md){return(
md`Here is a scatterplot of the first two dimensions for comparison`
)}

function _basicScatterplot(vl,selectedColumns,sizeCol,numericColumns,colorCol,filteredData){return(
vl
  .markCircle({ tooltip: { data: true } })
  .encode(
    vl.x().fieldQ(selectedColumns[0]),
    vl.size().fieldQ(sizeCol),
    vl.y().fieldQ(selectedColumns[1]),
    numericColumns.includes(colorCol) ? 
      vl.color().fieldQ(colorCol) :
      vl.color().field(colorCol) 
  )
  .data(filteredData)
  .render()
)}

function _21(md){return(
md`---
## Data
Format data for UMAP, it expects a matrix of numbers`
)}

function _details(Inputs,selectedScatterplot){return(
Inputs.table(selectedScatterplot)
)}

function _dataAsMatrix(filteredData,selectedColumns)
{
  return filteredData.map(d => selectedColumns.map(c => d[c]))
}


function _numericColumns(columns,data){return(
columns.filter(c => typeof(data[0][c]) === "number")
)}

function _columns(data){return(
data.length > 0 ? Object.keys(data[0]) : []
)}

function _filteredDataWithCoords(umapStatus,filteredData)
{
  const embedding = umapStatus.embedding;
  return filteredData.map((d, i) => ({
    ...d,
    x: embedding[i][0],
    y: embedding[i][1]
  }));
}


function _selectedScatterplot(filteredDataWithCoords,scatterplot){return(
filteredDataWithCoords.filter(
  (d) =>
    !scatterplot.brush ||
    (d.x >= scatterplot.brush.x[0] && d.x <= scatterplot.brush.x[1]) &&
    (d.y >= scatterplot.brush.y[0] && d.y <= scatterplot.brush.y[1])
)
)}

function _navioOptions(){return(
{
  attribWidth : 12,
  y0 : 70,
  height: 300
}
)}

function _29(md){return(
md`---
UMAP

Uses a modified version of [@fil UMAP-worker](https://observablehq.com/@fil/umap-js-worker)
`
)}

function _umapStatus(Generators,worker,fit,dataAsMatrix,show_dynamic,nComponents,minDist,nNeighbors,spread,seed){return(
Generators.observe(
  worker(
    fit,
    {
      dataAsMatrix,
      show_dynamic,
      options: {
        nComponents,
        minDist,
        nNeighbors,
        spread
      }
    },
    `
const window = {};
importScripts("https://unpkg.com/umap-js@1.3.2/lib/umap-js.js");
importScripts("https://unpkg.com/d3-random@2");
const UMAP = window.UMAP;

Math.random = d3.randomLcg(${seed});

    `
  )
)
)}

function _fit(UMAP){return(
function* fit({ dataAsMatrix, show_dynamic, options }) {
  
  //Yield something before reinitializing
  yield { 
    status: "Initializing",
    currentEpoch: 0,
    targetEpoch: 0,
    embedding: dataAsMatrix.map(_ => [Math.random(), Math.random()])
  };
  
  const umap = new UMAP(options),
    nEpochs = umap.initializeFit(dataAsMatrix);    

  yield { 
    status: "Starting",
    currentEpoch: 0,
    targetEpoch: nEpochs,
    embedding: umap.getEmbedding()
  };
  
  for (let i = 0; i < nEpochs; i++) {
    umap.step();
    if (show_dynamic && i%5 ===0) {
        yield { 
          status: "Running",
          currentEpoch: i,
          targetEpoch: nEpochs,
          embedding: umap.getEmbedding()
        };
    }
  }
  yield { 
    status: "Finished",
    currentEpoch: nEpochs,
    targetEpoch: nEpochs,
    embedding: umap.getEmbedding()
  };
}
)}

function _32(md){return(
md`---
## Imports
`
)}

function _d3(require){return(
require("d3-dsv")
)}

function _UMAP(){return(
"🌶"
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["nutrients.csv", {url: new URL("./files/12dfe34b39062185eccb40d841448bd2389abcbeb9f0b424840f5dc407accc1a2fbef1eae9600733d13fb1333c9b82807438bf3a5c4b8637d7b27c6a906b0af2.csv", import.meta.url), mimeType: "text/csv", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("viewof data")).define("viewof data", ["dataInput","FileAttachment","d3","fileType"], _data);
  main.variable(observer("data")).define("data", ["Generators", "viewof data"], (G, _) => G.input(_));
  main.variable(observer("viewof fileType")).define("viewof fileType", ["Inputs"], _fileType);
  main.variable(observer("fileType")).define("fileType", ["Generators", "viewof fileType"], (G, _) => G.input(_));
  main.variable(observer("viewof filteredData")).define("viewof filteredData", ["conditionalShow","navio","data","navioOptions","htl"], _filteredData);
  main.variable(observer("filteredData")).define("filteredData", ["Generators", "viewof filteredData"], (G, _) => G.input(_));
  main.variable(observer("status")).define("status", ["html","umapStatus"], _status);
  main.variable(observer("viewof scatterplot")).define("viewof scatterplot", ["vl","numericColumns","colorCol","filteredDataWithCoords","sizeCol","width","vegaSelected"], _scatterplot);
  main.variable(observer("scatterplot")).define("scatterplot", ["Generators", "viewof scatterplot"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _7);
  main.variable(observer("viewof selectedColumns")).define("viewof selectedColumns", ["searchCheckbox","columns","numericColumns"], _selectedColumns);
  main.variable(observer("selectedColumns")).define("selectedColumns", ["Generators", "viewof selectedColumns"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _9);
  main.variable(observer("viewof minDist")).define("viewof minDist", ["slider"], _minDist);
  main.variable(observer("minDist")).define("minDist", ["Generators", "viewof minDist"], (G, _) => G.input(_));
  main.variable(observer("viewof spread")).define("viewof spread", ["slider"], _spread);
  main.variable(observer("spread")).define("spread", ["Generators", "viewof spread"], (G, _) => G.input(_));
  main.variable(observer("viewof nNeighbors")).define("viewof nNeighbors", ["slider"], _nNeighbors);
  main.variable(observer("nNeighbors")).define("nNeighbors", ["Generators", "viewof nNeighbors"], (G, _) => G.input(_));
  main.variable(observer("viewof nComponents")).define("viewof nComponents", ["slider"], _nComponents);
  main.variable(observer("nComponents")).define("nComponents", ["Generators", "viewof nComponents"], (G, _) => G.input(_));
  main.variable(observer("viewof seed")).define("viewof seed", ["number"], _seed);
  main.variable(observer("seed")).define("seed", ["Generators", "viewof seed"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _15);
  main.variable(observer("viewof show_dynamic")).define("viewof show_dynamic", ["checkbox"], _show_dynamic);
  main.variable(observer("show_dynamic")).define("show_dynamic", ["Generators", "viewof show_dynamic"], (G, _) => G.input(_));
  main.variable(observer("viewof sizeCol")).define("viewof sizeCol", ["select","selectedColumns"], _sizeCol);
  main.variable(observer("sizeCol")).define("sizeCol", ["Generators", "viewof sizeCol"], (G, _) => G.input(_));
  main.variable(observer("viewof colorCol")).define("viewof colorCol", ["select","columns","numericColumns"], _colorCol);
  main.variable(observer("colorCol")).define("colorCol", ["Generators", "viewof colorCol"], (G, _) => G.input(_));
  main.variable(observer()).define(["md"], _19);
  main.variable(observer("basicScatterplot")).define("basicScatterplot", ["vl","selectedColumns","sizeCol","numericColumns","colorCol","filteredData"], _basicScatterplot);
  main.variable(observer()).define(["md"], _21);
  main.variable(observer("viewof details")).define("viewof details", ["Inputs","selectedScatterplot"], _details);
  main.variable(observer("details")).define("details", ["Generators", "viewof details"], (G, _) => G.input(_));
  main.variable(observer("dataAsMatrix")).define("dataAsMatrix", ["filteredData","selectedColumns"], _dataAsMatrix);
  main.variable(observer("numericColumns")).define("numericColumns", ["columns","data"], _numericColumns);
  main.variable(observer("columns")).define("columns", ["data"], _columns);
  main.variable(observer("filteredDataWithCoords")).define("filteredDataWithCoords", ["umapStatus","filteredData"], _filteredDataWithCoords);
  main.variable(observer("selectedScatterplot")).define("selectedScatterplot", ["filteredDataWithCoords","scatterplot"], _selectedScatterplot);
  main.variable(observer("navioOptions")).define("navioOptions", _navioOptions);
  main.variable(observer()).define(["md"], _29);
  main.variable(observer("umapStatus")).define("umapStatus", ["Generators","worker","fit","dataAsMatrix","show_dynamic","nComponents","minDist","nNeighbors","spread","seed"], _umapStatus);
  main.variable(observer("fit")).define("fit", ["UMAP"], _fit);
  main.variable(observer()).define(["md"], _32);
  main.variable(observer("d3")).define("d3", ["require"], _d3);
  const child1 = runtime.module(define1);
  main.import("vl", child1);
  const child2 = runtime.module(define2);
  main.import("checkbox", child2);
  main.import("number", child2);
  main.import("slider", child2);
  main.import("select", child2);
  main.variable(observer("UMAP")).define("UMAP", _UMAP);
  const child3 = runtime.module(define3);
  main.import("dataInput", child3);
  const child4 = runtime.module(define4);
  main.import("worker", child4);
  const child5 = runtime.module(define5);
  main.import("navio", child5);
  const child6 = runtime.module(define6);
  main.import("searchCheckbox", child6);
  const child7 = runtime.module(define7);
  main.import("vegaSelected", child7);
  const child8 = runtime.module(define8);
  main.import("conditionalShow", child8);
  return main;
}
