function _1(md){return(
md`# Worker

This utility helps to create Web Workers, that run computations outside of the main thread, allowing them to run for a long period of time without hanging the browser.

Usage:

~~~{javascript}
import { observeWorker as worker } from "@fil/worker"
worker\`
  importScripts("https://unpkg.com/d3-delaunay@6");
  function heavyComputation(values) { … };
  return heavyComputation(\${values});
\`
~~~

This new API **is not yet stabilized**! Details in [An update to the worker utility](https://observablehq.com/@fil/worker-utility-update).

---

The old API is unchanged:

~~~{javascript}
import { worker } from "@fil/worker"
Generators.queue(worker(my_function, arg))
~~~

See it in action at https://observablehq.com/@fil/lap-jv and https://observablehq.com/@fil/tsne-js-worker

---

To use ES6 [modules](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules) in the worker code, add \`{type: "module"}\` to the options.

~~~{javascript}
import {worker} from "@fil/worker"
Generators.queue(worker(my_function, {...arg, type: "module"}))
~~~
`
)}

function _2(Generators,worker,blah){return(
Generators.queue(worker(blah, 100))
)}

function _3(Generators,worker,blah){return(
Generators.observe(worker(blah, 100000))
)}

function _4(Generators,worker,who){return(
Generators.queue(worker(who, { n: 100, k: 21 }))
)}

function _5(Generators,worker,meh){return(
Generators.queue(worker(meh))
)}

function _6(Generators,worker){return(
Generators.queue(worker(() => "foo"))
)}

function _7(Generators,worker){return(
Generators.queue(
  worker(async function* () {
    for (let i = 0; i < 100; i++) {
      yield i;
    }
  })
)
)}

function _8(Generators,worker,dthree){return(
Generators.queue(
  worker(
    function () {
      return dthree.range(0, 10);
    },
    { type: "module" },
    `import * as dthree from "https://cdn.jsdelivr.net/npm/d3@7/+esm";`
  )
)
)}

function _dthree(){return(
null
)}

function _10(observeWorker){return(
observeWorker`return await fetch("https://d3js.org/").then(d => d.text()).then(text => text.length);`
)}

function _webWorker(function_stringify,Generators,worker){return(
(method) =>
  function (f, ...vars) {
    let t = f[0];
    const args = {};
    for (let i = 0; i < vars.length; i++) {
      t = `${t}${
        typeof vars[i] === "function"
          ? function_stringify(vars[i])
          : ((args[`a${i}`] = vars[i]), `data.a${i}`)
      }${f[i + 1]}`;
    }
    // auto-detect async functions
    const _async = t.match(/\b(await|async)\b/) ? "async " : "";

    return Generators[method](
      worker(
        {
          toString: () => `${_async}function main(data) {\n${t}\n;;;\n}`,
          name: "main"
        },
        args
      )
    );
  }
)}

function _queueWorker(webWorker){return(
webWorker("queue")
)}

function _observeWorker(webWorker){return(
webWorker("observe")
)}

function _worker(workertext){return(
function (f, e, preamble, transferList) {
  const b = new Blob([workertext(f, preamble)], { type: "text/javascript" });
  return function (notify) {
    const url = URL.createObjectURL(b);

    const worker = new Worker(url, { type: (e && e?.type) || "classic" }); 
    worker.addEventListener("message", (r) => notify(r.data));
    worker.postMessage(e, transferList);
    return () => {
      worker.terminate();
      URL.revokeObjectURL(url);
    };
  };
}
)}

function _workertext(function_stringify){return(
function workertext(f, preamble = "") {
  return `
${preamble}

function isIterable(obj) {
  return (
    typeof obj[Symbol.iterator] === "function" &&
    typeof obj["next"] == "function"
  );
}

const __run__ = ${typeof f === "function" ? function_stringify(f) : f};

self.onmessage = async function(e) {
  const t0 = performance.now();
  let result = await __run__(e.data);

  const postHelper = p => 
   postMessage(
      typeof p !== "object" || !Object.isExtensible(p) ? 
        p : 
        Object.assign(p, {_time: performance.now() - t0})
    );
 
  if (typeof result[Symbol.asyncIterator] === "function") {
    for await (const p of result) {
      postHelper(p);
    }
    close();
  }
  if (typeof result !== "undefined") {
    if (!isIterable(result)) result = [result];
    for (const p of result) {
      postHelper(p);
    }
    close();
  }

}`;
}
)}

function _function_stringify(){return(
function function_stringify(f) {
  let g = f.toString();
  if (f.prototype && f.prototype.toString() === "[object Generator]")
    g = g.replace(/function\*?/, "function*");
  return g;
}
)}

function _blah(){return(
function* blah(n) {
  let sum = 0;
  while (n-- > 0) yield (sum += n);
}
)}

function _who(){return(
function* who({ n, k }) {
  let sum = 0;
  while (n-- > 0) yield k * (sum += n);
}
)}

function _meh(){return(
function meh() {
  let sum = 0,
    n = 100;
  while (n-- > 0) {
    sum += n;
  }
  return sum;
}
)}

function _20(md){return(
md`## 🌶 Hot zone

You can also pass functions directly:`
)}

function _21(Generators,worker){return(
Generators.queue(worker(d => d ** 2, 10))
)}

function _22(md){return(
md`Now we will try something much more complicated: to get a Delaunay triangulation from the web worker. We can't pass it d3, an object that can't be cloned, but we can call the "d3-delaunay" script from the worker, and use it then. We'll manipulate its name ("de" instead of "d3") so that we don't pollute our main thread. The third argument of \`worker\` is a preamble text to initialize the worker script.`
)}

function _23(Generators,worker,delaunay){return(
Generators.queue(
  worker(
    delaunay,
    [0, 0, 1, 2.1, 4, 3],
    `
importScripts("https://unpkg.com/d3-delaunay");
const de = d3;
    `
  )
)
)}

function _25(Generators,worker,delaunay){return(
Generators.queue(
  worker(
    delaunay,
    Object.assign([0, 0, 1, 2.1, 4, 3], {type: "module"}),
    `
import * as d3 from "https://cdn.jsdelivr.net/npm/d3-delaunay/+esm";
const de = d3;
    `
  )
)
)}

function _delaunay(de){return(
function delaunay(data) {
  return new de.Delaunay(Float32Array.from(data));
}
)}

function _de(){return(
"🤯"
)}

function _28(md){return(
md`
Remark: we don't use [\`Generators.worker\`](https://github.com/observablehq/notebook-stdlib/blob/master/README.md#Generators_worker); see [this thread](https://talk.observablehq.com/t/help-with-generators-worker/937) for detailed explanations, and [this example](https://beta.observablehq.com/d/e2a6bd734b15a886) nonetheless.
`
)}

function _29(md){return(
md`Note: the fourth argument to \`worker\` is an (optional) \`transferList\`, see [reference](https://developer.mozilla.org/en-US/docs/Web/API/Worker/postMessage) and [example](https://beta.observablehq.com/@fil/hello-offscreen-canvas).`
)}

function _30(md){return(
md`---

See [notebook-stdlib](https://github.com/observablehq/notebook-stdlib/#generators) for more documentation, and these two notebooks by Mike Bostock for a slightly different approach: [Computing π](https://observablehq.com/@mbostock/computing-pi); [Voronoi Stippling](https://observablehq.com/@mbostock/voronoi-stippling).

Thanks to [Radamés Ajna](https://observablehq.com/@radames) for the support for async functions (Nov. 2019), and to [Fabian Iwand](https://observablehq.com/@mootari) for the support of anonymous functions (Feb. 2022).

See also https://observablehq.com/@galopin/work-work`
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["Generators","worker","blah"], _2);
  main.variable(observer()).define(["Generators","worker","blah"], _3);
  main.variable(observer()).define(["Generators","worker","who"], _4);
  main.variable(observer()).define(["Generators","worker","meh"], _5);
  main.variable(observer()).define(["Generators","worker"], _6);
  main.variable(observer()).define(["Generators","worker"], _7);
  main.variable(observer()).define(["Generators","worker","dthree"], _8);
  main.variable(observer("dthree")).define("dthree", _dthree);
  main.variable(observer()).define(["observeWorker"], _10);
  main.variable(observer("webWorker")).define("webWorker", ["function_stringify","Generators","worker"], _webWorker);
  main.variable(observer("queueWorker")).define("queueWorker", ["webWorker"], _queueWorker);
  main.variable(observer("observeWorker")).define("observeWorker", ["webWorker"], _observeWorker);
  main.variable(observer("worker")).define("worker", ["workertext"], _worker);
  main.variable(observer("workertext")).define("workertext", ["function_stringify"], _workertext);
  main.variable(observer("function_stringify")).define("function_stringify", _function_stringify);
  main.variable(observer("blah")).define("blah", _blah);
  main.variable(observer("who")).define("who", _who);
  main.variable(observer("meh")).define("meh", _meh);
  main.variable(observer()).define(["md"], _20);
  main.variable(observer()).define(["Generators","worker"], _21);
  main.variable(observer()).define(["md"], _22);
  main.variable(observer()).define(["Generators","worker","delaunay"], _23);
  main.variable(observer()).define(["Generators","worker","delaunay"], _25);
  main.variable(observer("delaunay")).define("delaunay", ["de"], _delaunay);
  main.variable(observer("de")).define("de", _de);
  main.variable(observer()).define(["md"], _28);
  main.variable(observer()).define(["md"], _29);
  main.variable(observer()).define(["md"], _30);
  return main;
}
